import React, { Component } from "react";
import { FormControl, TextField } from "@material-ui/core";

class LoginForm extends Component {
  render() {
    return (
      <FormControl>
        <TextField />
      </FormControl>
    );
  }
}

export default LoginForm;
